package org.iap.mcdrift.command;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2561;
import org.iap.mcdrift.IapDriftMod;

import static net.minecraft.class_2170.method_9247;

public class IapDriftCommands {
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            LiteralArgumentBuilder<class_2168> root = method_9247("iapdrift")
                    .requires(source -> source.method_9259(2))
                    .then(method_9247("status").executes(context -> {
                        class_2168 source = context.getSource();
                        source.method_9226(class_2561.method_43470("[IAP-Drift] active=" + IapDriftMod.config().active), false);
                        source.method_9226(class_2561.method_43470("[IAP-Drift] total tasks=" + IapDriftMod.config().tasks.size()
                                + ", enabled=" + IapDriftMod.config().enabledTaskCount()
                                + ", active block-break gates=" + IapDriftMod.config().getActiveBlockBreakTasks().size()), false);
                        source.method_9226(class_2561.method_43470("[IAP-Drift] truth log=" + IapDriftMod.truthLogger().getLogPath()), false);
                        return 1;
                    }))
                    .then(method_9247("reload").executes(context -> {
                        IapDriftMod.reloadConfig();
                        context.getSource().method_9226(class_2561.method_43470("[IAP-Drift] config reloaded."), false);
                        return 1;
                    }))
                    .then(method_9247("dump").executes(context -> {
                        class_2168 source = context.getSource();
                        IapDriftMod.config().getActiveBlockBreakTasks().forEach(task ->
                                source.method_9226(class_2561.method_43470("[IAP-Drift] " + task.id + " "
                                        + task.action + " " + task.ground_truth + " targets=" + task.target_blocks), false));
                        return 1;
                    }));

            dispatcher.register(root);
        });
    }
}
