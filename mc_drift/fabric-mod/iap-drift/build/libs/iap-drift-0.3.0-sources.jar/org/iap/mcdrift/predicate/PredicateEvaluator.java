package org.iap.mcdrift.predicate;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class PredicateEvaluator {
    private static final Pattern Y_LEVEL_LEQ =
            Pattern.compile("^y_level\\(y\\)\\s*<=\\s*(-?\\d+)$");

    public static EvalResult evaluate(String predicate, class_3222 player, class_3218 world, class_2338 targetPos) {
        String normalized = predicate == null ? "" : predicate.trim().replaceAll("\\s+", " ");
        Matcher yMatcher = Y_LEVEL_LEQ.matcher(normalized);
        if (yMatcher.matches()) {
            int threshold = Integer.parseInt(yMatcher.group(1));
            int y = targetPos != null ? targetPos.method_10264() : player.method_31478();
            boolean passed = y <= threshold;
            return new EvalResult(passed, "y=" + y + ", threshold=" + threshold);
        }

        return new EvalResult(false, "unsupported predicate in Phase 3-4: " + normalized);
    }

    public static class EvalResult {
        public final boolean passed;
        public final String detail;

        public EvalResult(boolean passed, String detail) {
            this.passed = passed;
            this.detail = detail;
        }
    }
}
