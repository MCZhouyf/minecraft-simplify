package org.iap.mcdrift.gate;

import com.google.gson.JsonObject;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import org.iap.mcdrift.IapDriftMod;
import org.iap.mcdrift.config.DriftTask;
import org.iap.mcdrift.predicate.PredicateEvaluator;

public class MiningGate {
    public static void register() {
        PlayerBlockBreakEvents.BEFORE.register((world, player, pos, state, blockEntity) -> {
            if (world.method_8608()) {
                return true;
            }
            if (!(player instanceof class_3222 serverPlayer) || !(world instanceof class_3218 serverWorld)) {
                return true;
            }
            if (!IapDriftMod.config().active) {
                return true;
            }

            class_2960 blockId = class_2378.field_11146.method_10221(state.method_26204());
            String blockName = blockId.toString();

            for (DriftTask task : IapDriftMod.config().getActiveBlockBreakTasks()) {
                if (task.target_blocks == null || !task.target_blocks.contains(blockName)) {
                    continue;
                }

                PredicateEvaluator.EvalResult result =
                        PredicateEvaluator.evaluate(task.ground_truth, serverPlayer, serverWorld, pos);

                JsonObject event = new JsonObject();
                event.addProperty("task_id", task.id);
                event.addProperty("action", task.action);
                event.addProperty("event", "block_break");
                event.addProperty("target_block", blockName);
                event.addProperty("x", pos.method_10263());
                event.addProperty("y", pos.method_10264());
                event.addProperty("z", pos.method_10260());
                event.addProperty("ground_truth", task.ground_truth);
                event.addProperty("gate_value", result.passed);
                event.addProperty("gate_detail", result.detail);
                event.addProperty("allowed", result.passed);
                event.addProperty("player", serverPlayer.method_7334().getName());
                IapDriftMod.truthLogger().log(event);

                if (!result.passed) {
                    String message = task.public_failure_message == null || task.public_failure_message.isBlank()
                            ? IapDriftMod.config().public_failure_message
                            : task.public_failure_message;
                    serverPlayer.method_7353(class_2561.method_43470(message), false);
                    return false;
                }

                return true;
            }

            return true;
        });
    }
}
